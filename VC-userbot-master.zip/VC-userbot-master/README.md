README.md<h2 align="center">
    𓆩〭⃛〬💔 ⃟⃟⃝⃪➖𝐁𝐄𝐒𝐓 𝐌𝐔𝐒𝐈𝐂 𝐁𝐎𝐓 💨
    
    
「[𓆩〭⃛〬💔 ⃟⃟⃝⃪➖𝐁𝐄𝐒𝐓 𝐌𝐔𝐒𝐈𝐂 𝐁𝐎𝐓 💨‌](https://t.me/Officialjay_store)」



<p align="center">
  <img src="https://telegra.ph/file/90128affe4ed7b70b10ab.jpg">
</p>


<p align="center">
<b>𝗗𝗘𝗣𝗟𝗢𝗬𝗠𝗘𝗡𝗧 𝗠𝗘𝗧𝗛𝗢𝗗𝗦</b>
</p>
<h3 align="center">
     ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ʜᴇʀᴏᴋᴜ 」─
</h3>
<p align="center"><a href="https://dashboard.heroku.com/new?template=https://github.com/DOMINATOR-XD/VC-userbot"> <img src="https://img.shields.io/badge/Deploy%20On%20Heroku-black?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>

<h3 align="center">
    ─「 sᴜᴩᴩᴏʀᴛ 」─
</h3>

<p align="center">
<a href="https://t.me/Dollx_spambot"><img src="https://img.shields.io/badge/-Support%20Group-blue.svg?style=for-the-badge&logo=Telegram"></a>
</p>

<p align="center">
<a href="https://t.me/DollxSpam_BOT"><img src="https://img.shields.io/badge/-Support%20Channel-blue.svg?style=for-the-badge&logo=Telegram"></a>
</p>

