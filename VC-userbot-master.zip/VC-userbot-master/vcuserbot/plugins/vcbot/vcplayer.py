# Powered By // @AdityaHalder //

__NAME__ = "VcPlayer"
__MENU__ = """
**Set Stream Chat And Play From
Anywhere You Want.**

`.cset` - Set Your Stream Chat.
`.cjoin` - Join Stream Chat VC.
`.clve` - Leave From Stream VC.
`.cply` - Play Your Audio Song.
`.cvply` - Play Your Video Song.
`.cpse` - Pause Running Stream.
`.crsm` - Resume Paused Stream.
`.cskp` - Skip To Next Song.
`.cstp` - Stop Streaming On Vc.
"""
